#include "semanticAlgo.h"

//Option =1: mapping using only protein sequence similarity
//Option =2: mapping using both protein function and protein sequence similarity

 void calculemain()
{
	 char ontology_file[] = "/home/warith/workspace/netcoffee-master/data/gene_ontology.1_2.obo";
	 char gene_association_file[] = "/home/warith/workspace/netcoffee-master/data/intact.gene_assocs.txt";

	// char gene_association_file[] = "/media/warith/DATA_01/Engelbert2/GOA/goa_uniprot_gcrp.gaf";


 char str1 [] ="/home/warith/workspace/netcoffee-master/data/mouse.pin";
 char str2 [] ="/home/warith/workspace/netcoffee-master/data/rat.pin";
 char str3 [] ="/home/warith/workspace/netcoffee-master/data/mouse_rat.blast_score";
 char str4 [] ="/home/warith/workspace/netcoffee-master/data/mouse_rat.gene_association";
  long option =2;

  //if (ArgI > 4) option =2;
  if (option  ==1) printf("PINALOG alignment using protein sequence similarity \n");
  if (option  ==2) printf("PINALOG alignment using protein sequence and function similarity \n");
 // mouse.pin rat.pin mouse_rat.blast_score
  FILE * pFile;
  	  pFile = fopen ("mouse.pin","r");
  	  if (pFile == NULL) {
  	       perror("Can't open file");
  	   }
  	  //for Annalyse
  A.Read(str1, 1);
  B.Read(str2, 1);
  //A.Read("mouse.pin", 1);
   // B.Read("rat.pin", 1);
  nodesA = A.get_cnodes();
  nodesB = B.get_cnodes();
  sizeA = A.get_num_nodes();
  sizeB = B.get_num_nodes();
  printf("option = %d\n",option);
  printf("Finish reading graph %s   %d proteins  %d interactions \n",  str1, sizeA, A.get_num_edges());
  printf("Finish reading graph %s   %d proteins  %d interactions \n",  str2, sizeB, B.get_num_edges());
  
  make_communities_files1(str1, str2);

  long templ;

  for(long i =0; i!= sizeA; ++i) {  templ = allnodes.Add(nodesA->GetLabel(i)); gg1.push_back(templ);}
  for(long i =0; i!= sizeB; ++i) {  templ = allnodes.Add(nodesB->GetLabel(i)); gg2.push_back(templ);}
  
  AA = Alloc1(sizeA);
 // if (AA ==NULL) return 1;
  BB = Alloc1(sizeB);
 // if (BB ==NULL) return 1;
  AB = Alloc2(sizeA, sizeB);
 // if (AB ==NULL) return 1;
  printf("Finish allocating space for  similarity matrix \n");

  ReadBlast(str3);
  printf("Finish reading blast score. Calculating sequence/function ratio ...\n");

  theta = GetSeqFuncRatio();
  printf("Ratio = %f\n Normalizing similarity matrix \n", theta);
  NormalizeDistMatrix();

  if (option == 2)
    {
      Ont.read_go_ids(ontology_file);
      Ont.read_relations(ontology_file);
      printf("Finish reading ontology\n");
      
      Ont.add_protein_associations(gene_association_file, allnodes.get_trie());
      FILE *fi = fopen(str4, "r");
      allnodes.add_gene_associations_isoform(fi, &Ont);
      fclose(fi);
      printf("Finish adding protein associations\n");
      //    fo = fopen("net1_net2.dist", "w");
      AddFuncSim();
      //      fclose(fo);

    }
  
  char outfile1[128], outfile2[128];
  sprintf(outfile1, "net1_net2.pinalog.nodes_algn.txt");
  sprintf(outfile2, "net1_net2.pinalog.edges_algn.txt");

  if (option ==1 ) mapping();
  if (option ==2 ) mapping();

  filter_results();
  write_aligned_pairs(outfile1);
  write_conserved_edges(outfile2);
  

  Free(sizeA, AA);
  Free(sizeB, BB);
  Free(sizeA, AB);

}
