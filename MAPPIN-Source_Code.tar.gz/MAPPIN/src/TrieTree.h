#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include "utility.h"

#ifndef __TrieTree__
#define __TrieTree__


#define SearchError -2
#define SearchNonExist -5

class CTrieNode{

  char label;
  long  index;
  long  id;
  long  nc;
  long  ns;
  CTrieNode **child;

public:
  CTrieNode();
  ~CTrieNode();
  long Exist(char *s);
  char Label() { return label;}
  long  ID() {return id;}
  void SetUp(char c) { label = c;}
  void SetUpIndex(long nid) { index = nid;}
  void SetUpID(long xid) {id = xid;}
  void ExtendSize(void);
  void Add(char *s, long nid, long *xid);
  void Add(long nid, char lab, long numchild, long  *children);
  void Add(long nid, char lab, long numchild) {index = nid; label = lab; nc = numchild; }
  void printNode(FILE *f);
  CTrieNode *Search(long xid) ;
} ;

class CTrieTree{

protected:
  #define MaxLen 128
  char buffer[MaxLen];
  long n;
  long nn;
  CTrieNode *R;

  void adddot(char *s);

public:
  CTrieTree();
  ~CTrieTree();
  void Read(FILE *f);
  void LoadTrie(FILE *f);
  long Search(char *s);
  long Add(char *s);
  void PrintTrie(FILE *f);
  long  Size() {return n;}
};


#endif
