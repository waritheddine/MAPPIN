#include <iostream>
#include <fstream>
#include <vector>
#include <omp.h>
#include <lemon/list_graph.h>
#include <lemon/smart_graph.h>
#include <lemon/arg_parser.h>
#include <lemon/time_measure.h>
#include "verbose.h"
#include "input/shrinknetwork.h"
#include "input/networkpool.h"
#include "input/recordstore.h"
#include "input/kp_graph.h"
#include "input/processprofile.h"
#include "analyze/mask_whitespace.h"
#include "algorithms/solution_x.h"
#include "algorithms/simulatedannealing.h"
#include "analyze/semantic_go.h"
#include "analyze/score_model.h"
#include "format/format.h"
#include "semanticAlgo.cpp"

using namespace std;
typedef lemon::ListGraph Graph;
typedef lemon::SmartGraph BpGraph;
typedef NetworkPool<Graph,BpGraph> InputGraph;
typedef KpGraph<InputGraph> InputKpGraph;

typedef struct _Option
{
  bool out;
  bool create_records;
  bool analyze;
  bool model;
  bool bscore;
  bool tcoffee;
  int task;
  double edgefactor;
  double alpha;
  double beta;
  double eta;
  int numspecies;
  int nmax;
  int temp;
  double thr;
	int numthreads;
  std::string alignmentfile;
  std::string avefunsimfile;
  std::string recordsfile;
  std::string scorefile;/// log-ratio scoring model
  std::string profile;
  std::string logfile;
  std::string formatfile;
  std::string orthologyfile;
  std::string randomfile;
  std::string distributionfile;
  std::string resultfolder;
  std::vector<std::string> blastfiles;
  std::vector<std::string> nullfiles;
  std::vector<std::string> networkfiles;
  std::vector<std::string> associationfiles;/// gene ontology association
  std::string goauniprotfile;/// gene ontology association
  _Option()
  : out(false), create_records(false),
  analyze(false), model(false),bscore(false),task(1),temp(50),thr(0.3),edgefactor(0.1),alpha(0.3),beta(1.0),eta(1.0),numspecies(2),nmax(2000)
  {
    profile="config/policy.input";
		numthreads=omp_get_max_threads();
		resultfolder="result/four_species/MAPPIN/";
  }
}Option;

typedef Solution_X<Graph, InputKpGraph, BpGraph, Option> Solution;
typedef RecordStore<InputKpGraph, Option> InputRecord;
typedef SimulatedAnnealing<InputRecord,Solution,InputGraph,Option> SimulatedAnnealingType;
typedef Format<InputGraph, Option> FormatType;
typedef GoList<InputGraph, Option> GoAnalyzer;


bool setParser(ArgParser& parser, Option& myoption)
{
  parser
  /// Option for package information
  .boolOption("version","Show the version number of MAPPIN.")
  .boolOption("alignment","Execute the alignment algorithm.")
  .boolOption("analyse","Make analysis on alignmenr result.")
  .optionGroup("method","version")
  .optionGroup("method","alignment")
  .optionGroup("method","analyse")
  .onlyOneGroup("method")
  .mandatoryGroup("method")
  .refOption("alignmentfile","The filename of alignment of protein-protein interaction networks",myoption.alignmentfile)
  .refOption("alpha", "Prameter controlling how much biological score contributes to the alignment score. Default is 0.3.", myoption.alpha)
  .refOption("edgefactor", "The factor of the power law normalization. Default is 0.1.", myoption.alpha)
  .refOption("numspecies","Number of the species used in the aligning process. Default is 3.", myoption.numspecies)
	.refOption("numthreads","Specifies the number of threads used to run MAPPIN. The recommended number of threads is the number of cores available in the computer", myoption.numthreads)
  .refOption("resultfolder","The folder which was used to store the alignment results.", myoption.resultfolder)
  .refOption("nmax","The parameter N for Simulated Annealing algorithm.",myoption.nmax)
  .refOption("temp","The number of iteration for Simulated Annealing algorithm.",myoption.temp)
  .refOption("thr","The threshold for the alignment of protein-protein interaction networks.",myoption.thr)
   .refOption("bscore","Define bitscore as the similarity for the edges.",myoption.bscore)
  ;
  return true;
}

bool runParser(ArgParser& myparser, Option& myoption)
{
  std::string filename;
  ProcessProfile<Option> myprofile(myoption.profile);
	myprofile.getOption(myoption);
  myparser.run();
  filename.append(myoption.resultfolder);
  return true;
}

int main(int argc, char** argv)
{
  ArgParser myparser(argc,argv);
    std::cout << "Max num threads=" <<omp_get_max_threads()<< std::endl;
  string recordsfile = "dataset/bldata/alignment_records_blast.data";
  string hmodelfile= "dataset/homology.model";
  string nmodelfile= "dataset/null.model";
   vector<string> filenames;
  string outputfile("result/alignment.network.data");
  Option myoption;
  g_verbosity = VERBOSE_DEBUG;

  setParser(myparser, myoption);
  runParser(myparser, myoption);

  InputKpGraph kpgraph(myoption.blastfiles,myoption.numspecies);
  InputRecord records(hmodelfile,nmodelfile,myoption);
  std::ofstream mylog(myoption.logfile,std::ios_base::out|std::ios_base::app);
  InputGraph networks;
  Timer t;
  

 if(myparser.given("version"))
  {
    std::cout <<"MAPPIN Version 1.0\
    Author: Warith Ediine DJEDDI\
    email: waritheddine@yahoo.fr"<<std::endl;
  }


  long option =2;
  char ontology_file[] = "data/gene_ontology.1_2.obo";
 	//char gene_association_file[] = "/home/warith/workspace/MAPPIN/data/intact.gene_assocs.txt";
 	// char gene_association_file[] = "/media/warith/9ED4227FD42259B3/GOA/goa_uniprot_gcrp.gaf";
  char gene_association_file[] = "/media/root/DATA_01/Engelbert2/GOA";
 	 //char gene_association_file[] = "data/goa/goa_uniprot_gcrp.gaf/goa_uniprot_gcrp.gaf";
 	 char str1 [] ="/home/warith/workspace/MAPPIN/data/mouse.pin";
 	 char str2 [] ="/home/warith/workspace/MAPPIN/data/rat.pin";
 	 char str3 [] ="/home/warith/workspace/MAPPIN/data/mouse_rat.blast_score";
 	 char str4 [] ="/home/warith/workspace/MAPPIN/data/mouse_rat.gene_association";

	 char str5 [] ="/home/warith/workspace/MAPPIN/data/dm.goa";
	 char str6 [] ="/home/warith/workspace/MAPPIN/data/ce.goa";
	 char str7 [] ="result/affectProtToGene.txt";
 	 //------------------------------------------
 	 if(myparser.given("alignment"))
  {
    t.restart();
    SimulatedAnnealingType simAnnealing(myoption);
    networks.initNetworkPool(myoption.networkfiles,myoption.numthreads);


    if (option == 2)
         {
    	printf("Started reading Gene Ontology\n");
           Ont.read_go_ids(ontology_file);
           Ont.read_relations(ontology_file);
           printf("Finished reading Gene Ontology\n");
           printf("Started adding protein associations from the UniProt-GOA Gene Association Files \n");
           Ont.add_protein_associationsMy(gene_association_file, allnodes.get_trie(), &Ont);
           FILE *fi1 = fopen(str7, "r");
           allnodes.add_gene_associations_isoform(fi1, &Ont);

           fclose(fi1);

           printf("Finished adding protein associations \n");

    records.createBpGraphAll(kpgraph,networks,allnodes.get_trie());
     simAnnealing.run_t(kpgraph,records,networks);
      mylog <<"------------------------MAPPIN------------------------------"<<std::endl;
      mylog <<"It takes "<<t <<" seconds to obtain the alignment with alpha "<<myoption.alpha<<"."<<std::endl;
    }
    t.stop();


        simAnnealing.printAlignment_t(myoption.alignmentfile, networks);
    	 FormatType myformat(myoption);
        		myformat.retrieveGIlist();


        		 GoAnalyzer analyzer(myoption);
        		    analyzer.goInitial();
        		      analyzer.readAlignment(myoption.alignmentfile.c_str());
        		      analyzer.getAlignmentCoverage(networks);
        		     analyzer.getNetworkAnnotation(networks);
        		      analyzer.getMulFunSim();
        		      analyzer.getEntropy();


  }
 	 else if (myparser.given("analyse"))
 	 {

 		networks.initNetworkPool(myoption.networkfiles,myoption.numthreads);
 		GoAnalyzer analyzer(myoption);
 		        		    analyzer.goInitial();
 		        		      analyzer.readAlignment(myoption.alignmentfile.c_str());
 		        		     analyzer.getAlignmentCoverage(networks);
 		        		     analyzer.getNetworkAnnotation(networks);
 		        		     analyzer.getMulFunSim();
 		        		     analyzer.getEntropy();


 	 }

  mylog.close();
  return 0;
}
