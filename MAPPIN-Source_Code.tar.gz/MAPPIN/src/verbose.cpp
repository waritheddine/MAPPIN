#include "verbose.h"

VerbosityLevel g_verbosity = VERBOSE_ESSENTIAL;
